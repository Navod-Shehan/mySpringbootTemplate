package com.springboot.myTemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyTemplateApplication.class, args);
	}

}
